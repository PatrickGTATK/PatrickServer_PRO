export const SignConfig = {
    apiKey: "",
    serviceUrl: ""
};
